# MSEN 403/655 Project Report Template

Two-column journal-style LaTeX template for Materials Design Studio project reports.

## Quick Start

1. **Copy this folder** to your local machine or Overleaf project
2. **Edit `main.tex`** - replace text in [brackets] with your content
3. **Add your references** to `mybib.bib`
4. **Add your figures** to the `Figures/` folder
5. **Compile** with pdfLaTeX + BibTeX

### Compilation Order
```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Or in Overleaf, just click "Recompile" (it handles this automatically).

## Files Included

| File | Purpose |
|------|---------|
| `main.tex` | Main document - edit this |
| `mybib.bib` | Bibliography database - add your references |
| `preamble.tex` | **Teaching guide** - explains LaTeX best practices |
| `Figures/` | Folder for your images |

## Using the Preamble Guide

The `preamble.tex` file is a **learning resource** that explains:
- What each package does
- How to format figures and tables
- Common LaTeX mistakes to avoid
- Best practices for scientific documents

**To use it as a reference:** Open it and read the comments.

**To use it in your document:** You can include it with `\input{preamble}` after your `\documentclass` line, though `main.tex` already includes the necessary packages.

## Template Structure

The template follows a standard scientific paper structure:

1. **Abstract** (150-250 words)
2. **Introduction** - Problem motivation and objectives
3. **Background** - Literature review
4. **Methodology** - Data and methods
5. **Results** - Findings with figures/tables
6. **Discussion** - Interpretation and limitations
7. **Conclusions** - Summary and next steps
8. **References**
9. **Appendix: AI Tool Usage** (REQUIRED)

## Required: AI Tool Usage Appendix

Every submission must include the AI Tool Usage appendix documenting:
- **Tools Used:** List all AI tools (or state "None")
- **Tasks:** What you used AI for
- **Verification:** How you checked AI outputs
- **Modifications:** Changes you made to AI-generated content

## Tips for Good Reports

### Figures
- Use **PDF format** for plots and diagrams (vector graphics)
- Use **PNG** for screenshots
- Use **JPG** only for photographs
- Always include descriptive captions
- Reference every figure in the text: "As shown in Figure 1..."

### Tables
- Caption goes **above** the table
- Use `\toprule`, `\midrule`, `\bottomrule` (not `\hline`)
- **Never** use vertical lines
- Align numbers by decimal point

### Citations
- Add entries to `mybib.bib`
- Cite with `\cite{key}` in your text
- Every claim needs a citation or your own data

### Common LaTeX Mistakes
```latex
% WRONG                    % RIGHT
"quoted text"              ``quoted text''
50%                        50\%
variable x                 variable $x$
Figure 1                   Figure~\ref{fig:label}
```

## Customizing for Each Stage

Adjust sections based on your Stage requirements:
- **Stage 1 (Establish):** Focus on problem definition, SNPS, functional analysis
- **Stage 2 (Explain):** Emphasize literature review and preliminary data analysis
- **Stage 3 (Explore):** Expand methodology and results (model development)
- **Stage 4 (Exploit):** Full report with optimization results and recommendations

## Getting Help

- **LaTeX help:** [Overleaf Documentation](https://www.overleaf.com/learn)
- **Course questions:** Post on Slack or attend office hours
- **Template issues:** Contact the course instructor

---
*MSEN 403/655: Materials Design Studio | Texas A&M University | Spring 2026*
